#!/usr/bin/env bash
# Usage: ./build.sh <paper-api-or-server.jar> [libraries-folder]
# Needs JDK 25 (Paper 26.3 API is compiled for Java 25). Use paper-api-26.3.*.jar from your libraries folder as the first argument.
# Example: ./build.sh ~/server/versions/26.3/paper-26.3.jar ~/server/libraries
set -e
API="$1"; LIBS="$2"
if [ -z "$API" ]; then echo "Usage: ./build.sh <paper jar> [libraries folder]"; exit 1; fi
CP="$API"
if [ -n "$LIBS" ]; then CP="$CP:$(find "$LIBS" -name '*.jar' | tr '\n' ':')"; fi
rm -rf build && mkdir -p build/classes
javac --release 25 -proc:none -cp "$CP" -d build/classes $(find src/main/java -name '*.java')
cp src/main/resources/* build/classes/
(cd build/classes && jar cf ../WinterWitch.jar .)
echo "Built build/WinterWitch.jar"
