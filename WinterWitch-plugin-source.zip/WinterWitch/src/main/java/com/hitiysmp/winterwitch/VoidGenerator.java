package com.hitiysmp.winterwitch;

import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Biome;
import org.bukkit.generator.BiomeProvider;
import org.bukkit.generator.ChunkGenerator;
import org.bukkit.generator.WorldInfo;

import java.util.List;
import java.util.Random;

/** Generates nothing (void) with a snowy biome, so the arena can be pasted onto empty space. */
public final class VoidGenerator extends ChunkGenerator {
    private final Location spawn;

    public VoidGenerator(double x, double y, double z) {
        this.spawn = new Location(null, x, y, z);
    }

    @Override
    public BiomeProvider getDefaultBiomeProvider(WorldInfo worldInfo) {
        return new BiomeProvider() {
            @Override
            public Biome getBiome(WorldInfo info, int x, int y, int z) {
                return Biome.SNOWY_PLAINS;
            }

            @Override
            public List<Biome> getBiomes(WorldInfo info) {
                return List.of(Biome.SNOWY_PLAINS);
            }
        };
    }

    @Override
    public Location getFixedSpawnLocation(World world, Random random) {
        return new Location(world, spawn.getX(), spawn.getY(), spawn.getZ());
    }
}
