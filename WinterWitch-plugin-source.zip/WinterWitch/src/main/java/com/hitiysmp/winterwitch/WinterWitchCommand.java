package com.hitiysmp.winterwitch;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class WinterWitchCommand implements CommandExecutor, TabCompleter {
    private static final List<String> SUB = List.of("summon", "stop", "status", "phase", "give", "setcoin", "paste", "arena", "reload");
    private static final List<String> ITEMS = List.of("coin", "frostbrand", "helmet", "chestplate", "leggings", "boots", "set", "sigil");

    private final WinterWitchPlugin plugin;

    WinterWitchCommand(WinterWitchPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        if (!s.hasPermission("winterwitch.admin")) {
            s.sendMessage(Util.mm("<red>No permission."));
            return true;
        }
        if (a.length == 0) {
            s.sendMessage(Util.mm("<aqua>/ww <white>summon | stop | status | phase <1-3> | give <player> <item> [amount] | setcoin | paste | arena [tp|leave] | reload"));
            return true;
        }
        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "summon" -> {
                if (!(s instanceof Player p)) {
                    s.sendMessage("Players only.");
                    return true;
                }
                String reason = plugin.bosses().blockReason();
                if (reason != null) {
                    s.sendMessage(Util.mm("<red>" + reason + " <gray>(use /ww stop to reset)"));
                    return true;
                }
                plugin.bosses().start(p.getLocation(), p);
            }
            case "stop" -> {
                plugin.bosses().stop();
                s.sendMessage(Util.mm("<aqua>Winter Witch stopped."));
            }
            case "status" -> {
                WitchBoss f = plugin.bosses().active();
                if (f == null) {
                    s.sendMessage(Util.mm("<gray>No active fight."));
                } else {
                    s.sendMessage(Util.mm("<aqua>Phase " + f.phase() + (f.enraged() ? " (enraged)" : "") + " <gray>- HP <white>"
                            + (int) f.currentHp() + "/" + (int) f.effectiveMax()));
                }
            }
            case "phase" -> {
                WitchBoss f = plugin.bosses().active();
                if (f == null || a.length < 2 || f.boss() == null) {
                    s.sendMessage(Util.mm("<red>Usage: /ww phase <2|3> during a fight."));
                    return true;
                }
                double ratio = a[1].equals("3") ? 0.34 : a[1].equals("2") ? 0.69 : 1.0;
                f.boss().setHealth(Math.min(f.boss().getHealth(), WitchBoss.POOL * ratio));
                s.sendMessage(Util.mm("<aqua>Boss health set for phase " + a[1] + "."));
            }
            case "give" -> {
                if (a.length < 3) {
                    s.sendMessage(Util.mm("<red>Usage: /ww give <player> <item> [amount]"));
                    return true;
                }
                Player t = Bukkit.getPlayerExact(a[1]);
                if (t == null) {
                    s.sendMessage(Util.mm("<red>Player not online."));
                    return true;
                }
                int amt = 1;
                if (a.length >= 4) {
                    try {
                        amt = Math.max(1, Integer.parseInt(a[3]));
                    } catch (NumberFormatException ex) {
                        s.sendMessage(Util.mm("<red>Amount must be a number."));
                        return true;
                    }
                }
                String what = a[2].toLowerCase(Locale.ROOT);
                if (what.equals("coin")) {
                    plugin.items().giveCoins(t, amt);
                } else if (what.equals("set")) {
                    for (String id : plugin.items().armorIds()) {
                        plugin.items().giveOrDrop(t, plugin.items().armorPiece(id));
                    }
                } else {
                    ItemStack it = plugin.items().byName(what);
                    if (it == null) {
                        s.sendMessage(Util.mm("<red>Unknown item. Options: " + String.join(", ", ITEMS)));
                        return true;
                    }
                    it.setAmount(Math.min(amt, it.getMaxStackSize()));
                    plugin.items().giveOrDrop(t, it);
                }
                s.sendMessage(Util.mm("<aqua>Gave " + what + " to " + t.getName() + "."));
            }
            case "setcoin" -> {
                if (!(s instanceof Player p)) {
                    s.sendMessage("Players only.");
                    return true;
                }
                ItemStack hand = p.getInventory().getItemInMainHand();
                if (hand.getType().isAir()) {
                    s.sendMessage(Util.mm("<red>Hold a real HitiyCoin in your main hand first."));
                    return true;
                }
                if (plugin.items().setCoinTemplate(hand)) {
                    s.sendMessage(Util.mm("<aqua>Reward coin saved - boss loot will now match the item in your hand exactly."));
                } else {
                    s.sendMessage(Util.mm("<red>Couldn't save coin.yml."));
                }
            }
            case "paste" -> {
                if (plugin.bosses().isBusy()) {
                    s.sendMessage(Util.mm("<red>Stop the current fight first (/ww stop)."));
                    return true;
                }
                if (!plugin.arena().startPaste(s)) {
                    s.sendMessage(Util.mm("<red>A paste is already running."));
                }
            }
            case "arena" -> {
                Arena ar = plugin.arena();
                if (a.length >= 2 && a[1].equalsIgnoreCase("tp")) {
                    if (!(s instanceof Player p) || ar.world() == null) {
                        s.sendMessage("Players only / arena world missing.");
                        return true;
                    }
                    p.teleport(ar.entry());
                    s.sendMessage(Util.mm("<aqua>Teleported to the arena entry. <gray>/ww arena leave to go back."));
                } else if (a.length >= 2 && a[1].equalsIgnoreCase("leave")) {
                    if (s instanceof Player p) {
                        ar.sendBack(p);
                    }
                } else {
                    s.sendMessage(Util.mm("<aqua>Arena: <white>" + (ar.isReady() ? "built" : ar.isPasting() ? "pasting..." : "NOT built (run /ww paste)")
                            + " <gray>- radius " + (int) ar.radius() + ", world "
                            + (ar.world() == null ? "missing" : ar.world().getName())));
                }
            }
            case "reload" -> {
                plugin.reload();
                s.sendMessage(Util.mm("<aqua>Reloaded."));
            }
            default -> s.sendMessage(Util.mm("<red>Unknown subcommand."));
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command cmd, String label, String[] a) {
        List<String> out = new ArrayList<>();
        if (!s.hasPermission("winterwitch.admin")) {
            return out;
        }
        if (a.length == 1) {
            for (String x : SUB) {
                if (x.startsWith(a[0].toLowerCase(Locale.ROOT))) {
                    out.add(x);
                }
            }
        } else if (a.length == 2 && a[0].equalsIgnoreCase("give")) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                out.add(p.getName());
            }
        } else if (a.length == 3 && a[0].equalsIgnoreCase("give")) {
            out.addAll(ITEMS);
        } else if (a.length == 2 && a[0].equalsIgnoreCase("arena")) {
            out.addAll(List.of("tp", "leave"));
        } else if (a.length == 2 && a[0].equalsIgnoreCase("phase")) {
            out.addAll(List.of("2", "3"));
        }
        return out;
    }
}
