package com.hitiysmp.winterwitch;

import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityCombustEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;

public final class BossListener implements Listener {
    private final WinterWitchPlugin plugin;

    BossListener(WinterWitchPlugin plugin) {
        this.plugin = plugin;
    }

    private WitchBoss fight() {
        return plugin.bosses().active();
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent e) {
        String role = plugin.roleOf(e.getEntity());
        if (role == null) {
            return;
        }
        WitchBoss f = fight();
        if (role.equals("boss")) {
            if (f == null || !f.isBoss(e.getEntity())) {
                return;
            }
            switch (e.getCause()) {
                case FALL, DROWNING, SUFFOCATION, FIRE, FIRE_TICK, LAVA, HOT_FLOOR, CRAMMING, FREEZE, CONTACT -> {
                    e.setCancelled(true);
                    return;
                }
                default -> {
                }
            }
            if (f.isInvulnerable()) {
                e.setCancelled(true);
                return;
            }
            boolean projectile = e instanceof EntityDamageByEntityEvent b && b.getDamager() instanceof Projectile;
            if (projectile && f.barrierUp()) {
                e.setCancelled(true);
                f.deflect();
                return;
            }
            e.setDamage(e.getDamage() * f.damageFactor());
        } else if (role.equals("decoy")) {
            e.setCancelled(true);
            if (f != null && e.getEntity() instanceof LivingEntity d) {
                Player by = null;
                if (e instanceof EntityDamageByEntityEvent b) {
                    if (b.getDamager() instanceof Player pl) {
                        by = pl;
                    } else if (b.getDamager() instanceof Projectile pr && pr.getShooter() instanceof Player sh) {
                        by = sh;
                    }
                }
                f.shatterDecoy(d, by);
            }
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDamageDealt(EntityDamageByEntityEvent e) {
        if (!"boss".equals(plugin.roleOf(e.getEntity()))) {
            return;
        }
        WitchBoss f = fight();
        if (f == null || !f.isBoss(e.getEntity())) {
            return;
        }
        Player p = null;
        boolean projectile = false;
        Entity damager = e.getDamager();
        if (damager instanceof Player pl) {
            p = pl;
        } else if (damager instanceof Projectile pr && pr.getShooter() instanceof Player sh) {
            p = sh;
            projectile = true;
        }
        if (p != null) {
            f.recordDamage(p, e.getFinalDamage(), projectile);
        }
    }

    @EventHandler
    public void onCombust(EntityCombustEvent e) {
        String role = plugin.roleOf(e.getEntity());
        if ("boss".equals(role) || "decoy".equals(role)) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onDeath(EntityDeathEvent e) {
        String role = plugin.roleOf(e.getEntity());
        if (role == null) {
            return;
        }
        e.getDrops().clear();
        e.setDroppedExp(0);
        if (role.equals("boss")) {
            WitchBoss f = fight();
            if (f != null && f.isBoss(e.getEntity())) {
                f.onBossDeath();
            }
        }
    }
}
