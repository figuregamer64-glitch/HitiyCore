package com.hitiysmp.winterwitch;

import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.GameMode;
import org.bukkit.GameRule;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/**
 * The mammoth-walley crater. Lives in its own void world; the schematic is pasted once with /ww paste.
 * Schematic x/z/y coordinates (config arena.*) are measured from the schematic's min corner, which is
 * pasted at world (0, paste-y, 0).
 */
public final class Arena {
    private final WinterWitchPlugin plugin;
    private final File stateFile;
    private final Map<UUID, Location> returnPoints = new HashMap<>();
    private final Random rnd = new Random();
    private World world;
    private boolean pasted;
    private BukkitTask pasteTask;

    Arena(WinterWitchPlugin plugin) {
        this.plugin = plugin;
        this.stateFile = new File(plugin.getDataFolder(), "arena-state.yml");
        if (stateFile.exists()) {
            pasted = YamlConfiguration.loadConfiguration(stateFile).getBoolean("pasted", false);
        }
    }

    private FileConfiguration cfg() {
        return plugin.getConfig();
    }

    // ------------------------------------------------------------------ world

    /** Creates/loads the arena world. Safe to call repeatedly. */
    World ensureWorld() {
        if (world != null) {
            return world;
        }
        String name = cfg().getString("arena.world", "winter_arena");
        World existing = Bukkit.getWorld(name);
        if (existing == null) {
            WorldCreator wc = new WorldCreator(name);
            wc.generator(new VoidGenerator(cx() + 0.5, py() + floorY() + 1, cz() + 0.5));
            wc.generateStructures(false);
            existing = wc.createWorld();
        }
        world = existing;
        if (world != null) {
            try {
                world.setGameRule(GameRule.DO_MOB_SPAWNING, false);
                world.setGameRule(GameRule.DO_DAYLIGHT_CYCLE, false);
                world.setGameRule(GameRule.DO_WEATHER_CYCLE, false);
                world.setGameRule(GameRule.DO_FIRE_TICK, false);
            } catch (Throwable t) {
                plugin.getLogger().warning("Could not set arena game rules: " + t);
            }
            world.setTime(18000);
            world.setSpawnLocation(entry());
        }
        return world;
    }

    public World world() {
        return world;
    }

    public boolean isArenaWorld(World w) {
        return w != null && world != null && w.getUID().equals(world.getUID());
    }

    public boolean isReady() {
        return pasted && world != null;
    }

    public boolean isPasting() {
        return pasteTask != null;
    }

    // ------------------------------------------------------------------ geometry (config -> world coords)

    private int cx() {
        return cfg().getInt("arena.center-x", 96);
    }

    private int cz() {
        return cfg().getInt("arena.center-z", 128);
    }

    private int py() {
        return cfg().getInt("arena.paste-y", 64);
    }

    private int floorY() {
        return cfg().getInt("arena.floor-y", 10);
    }

    public double radius() {
        return cfg().getDouble("arena.radius", 50);
    }

    /** Standing position at the middle of the arena (feet level). */
    public Location home() {
        return new Location(world, cx() + 0.5, py() + floorY() + 1, cz() + 0.5);
    }

    public Location entry() {
        return new Location(world, cfg().getInt("arena.entry-x", 130) + 0.5, py() + floorY() + 1,
                cfg().getInt("arena.entry-z", 128) + 0.5);
    }

    /** Finds ground near the floor level at (x, z): first solid non-barrier block with 2 free blocks above. */
    private Location standAt(double x, double z) {
        int bx = (int) Math.floor(x);
        int bz = (int) Math.floor(z);
        int top = py() + floorY() + 6;
        int bottom = py() + floorY() - 4;
        for (int y = top; y >= bottom; y--) {
            Block b = world.getBlockAt(bx, y, bz);
            if (b.getType().isSolid() && b.getType() != Material.BARRIER
                    && world.getBlockAt(bx, y + 1, bz).isPassable()
                    && world.getBlockAt(bx, y + 2, bz).isPassable()) {
                return new Location(world, bx + 0.5, y + 1, bz + 0.5);
            }
        }
        return null;
    }

    // ------------------------------------------------------------------ gate: in and out

    /** Moves the players near the entry point of the arena, remembering where they came from. */
    void sendIn(Collection<Player> players) {
        Location entry = entry();
        for (Player p : players) {
            returnPoints.put(p.getUniqueId(), p.getLocation().clone());
            Location dest = null;
            for (int i = 0; i < 25 && dest == null; i++) {
                double a = rnd.nextDouble() * Math.PI * 2;
                double r = i == 0 ? 0 : 1 + rnd.nextDouble() * 4;
                Location cand = standAt(entry.getX() + Math.cos(a) * r, entry.getZ() + Math.sin(a) * r);
                if (cand != null) {
                    dest = cand;
                }
            }
            if (dest == null) {
                dest = entry;
            }
            dest.setYaw(90f);   // facing west, toward the crater center
            dest.setPitch(5f);
            p.teleport(dest);
            p.setFreezeTicks(0);
            p.sendMessage(Util.mm("<aqua>\u2744 <gray>The frozen gate pulls you into the crater..."));
        }
    }

    void sendBack(Player p) {
        Location back = returnPoints.remove(p.getUniqueId());
        if (back == null || back.getWorld() == null || isArenaWorld(back.getWorld())) {
            back = Bukkit.getWorlds().get(0).getSpawnLocation();
        }
        p.setFreezeTicks(0);
        p.teleport(back);
    }

    /** Sends every non-admin-inspecting player in the arena home. */
    void returnAll() {
        if (world == null) {
            return;
        }
        for (Player p : new ArrayList<>(world.getPlayers())) {
            if (p.getGameMode() == GameMode.SPECTATOR || p.getGameMode() == GameMode.CREATIVE && p.hasPermission("winterwitch.admin")) {
                continue;
            }
            p.sendMessage(Util.mm("<aqua>\u2744 <gray>The gate carries you home."));
            sendBack(p);
        }
        returnPoints.clear();
    }

    // ------------------------------------------------------------------ paste

    /** Reads the schematic async, then pastes it into the arena world in small per-tick slices. */
    public boolean startPaste(CommandSender sender) {
        if (pasteTask != null) {
            return false;
        }
        if (ensureWorld() == null) {
            sender.sendMessage(Util.mm("<red>Couldn't create the arena world."));
            return false;
        }
        String fileName = cfg().getString("arena.schematic", "winter_arena.schem");
        File f = new File(plugin.getDataFolder(), fileName);
        if (!f.exists()) {
            plugin.saveResource("winter_arena.schem", false);
            if (!fileName.equals("winter_arena.schem")) {
                f = new File(plugin.getDataFolder(), "winter_arena.schem");
            }
        }
        final File schemFile = f;
        setPasted(false);
        pasteTask = Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                SchemReader.Schem s = SchemReader.read(schemFile);
                Bukkit.getScheduler().runTask(plugin, () -> beginPaste(sender, s));
            } catch (IOException | RuntimeException ex) {
                plugin.getLogger().warning("Schematic read failed: " + ex);
                Bukkit.getScheduler().runTask(plugin, () -> {
                    pasteTask = null;
                    sender.sendMessage(Util.mm("<red>Couldn't read the schematic: " + ex.getMessage()));
                });
            }
        });
        sender.sendMessage(Util.mm("<aqua>Reading schematic..."));
        return true;
    }

    private void beginPaste(CommandSender sender, SchemReader.Schem s) {
        // Build block data per palette entry. Trial spawners (and spawners) become stone so nothing spawns mid-fight.
        final BlockData[] data = new BlockData[s.palette.length];
        int swapped = 0;
        int bad = 0;
        for (int i = 0; i < s.palette.length; i++) {
            String name = s.palette[i];
            if (name == null || name.startsWith("minecraft:air") || name.startsWith("minecraft:cave_air")
                    || name.startsWith("minecraft:void_air")) {
                continue;
            }
            if (name.startsWith("minecraft:trial_spawner") || name.startsWith("minecraft:spawner")) {
                name = "minecraft:stone";
                swapped++;
            }
            try {
                data[i] = Bukkit.createBlockData(name);
            } catch (IllegalArgumentException ex) {
                bad++;
                plugin.getLogger().warning("Unknown block in schematic, skipped: " + name);
            }
        }
        long total = 0;
        for (short v : s.data) {
            if (data[v] != null) {
                total++;
            }
        }
        final long totalBlocks = total;
        final int w = s.width;
        final int h = s.height;
        final int l = s.length;
        final int ox = 0;
        final int oz = 0;
        final int oy = py();
        final long budgetNs = Math.max(2, cfg().getLong("arena.paste-budget-ms", 20)) * 1_000_000L;

        // Chunks the schematic covers.
        final List<int[]> chunks = new ArrayList<>();
        for (int chx = Math.floorDiv(ox, 16); chx <= Math.floorDiv(ox + w - 1, 16); chx++) {
            for (int chz = Math.floorDiv(oz, 16); chz <= Math.floorDiv(oz + l - 1, 16); chz++) {
                chunks.add(new int[]{chx, chz});
            }
        }
        sender.sendMessage(Util.mm("<aqua>Pasting <white>" + w + "x" + h + "x" + l + "</white> (" + totalBlocks
                + " blocks, " + chunks.size() + " chunks). This takes a few minutes; it's spread over many ticks."));
        if (swapped > 0 || bad > 0) {
            plugin.getLogger().info("Paste: " + swapped + " spawner types swapped for stone, " + bad + " unknown blocks skipped.");
        }

        final World wd = world;
        pasteTask = new BukkitRunnable() {
            int chunkIdx = 0;
            int cursor = 0;
            long placed = 0;
            int lastPct = -1;
            Chunk current = null;
            final int perChunk = 256 * h;

            @Override
            public void run() {
                long deadline = System.nanoTime() + budgetNs;
                int steps = 0;
                while (true) {
                    if (chunkIdx >= chunks.size()) {
                        finish();
                        return;
                    }
                    int[] cc = chunks.get(chunkIdx);
                    if (current == null) {
                        current = wd.getChunkAt(cc[0], cc[1]);
                        current.addPluginChunkTicket(plugin);
                    }
                    while (cursor < perChunk) {
                        int y = cursor >> 8;
                        int rem = cursor & 255;
                        int lz = rem >> 4;
                        int lx = rem & 15;
                        cursor++;
                        int wx = cc[0] * 16 + lx;
                        int wz = cc[1] * 16 + lz;
                        int sx = wx - ox;
                        int sz = wz - oz;
                        if (sx >= 0 && sx < w && sz >= 0 && sz < l) {
                            BlockData bd = data[s.data[sx + sz * w + y * w * l]];
                            if (bd != null) {
                                current.getBlock(lx, oy + y, lz).setBlockData(bd, false);
                                placed++;
                            }
                        }
                        if ((++steps & 127) == 0 && System.nanoTime() > deadline) {
                            report();
                            return;
                        }
                    }
                    current.removePluginChunkTicket(plugin);
                    current = null;
                    cursor = 0;
                    chunkIdx++;
                }
            }

            private void report() {
                int pct = (int) (placed * 100 / Math.max(1, totalBlocks));
                if (pct / 10 != lastPct / 10) {
                    lastPct = pct;
                    plugin.getLogger().info("Arena paste " + pct + "%");
                    if (sender instanceof Player pl && pl.isOnline()) {
                        pl.sendActionBar(Util.mm("<aqua>Arena paste: <white>" + pct + "%"));
                    }
                }
            }

            private void finish() {
                cancel();
                pasteTask = null;
                wd.setSpawnLocation(entry());
                wd.save();
                setPasted(true);
                plugin.getLogger().info("Arena paste complete (" + placed + " blocks).");
                sender.sendMessage(Util.mm("<aqua>\u2744 Arena built. <gray>Use <white>/ww arena tp</white> to look around, then summon the witch."));
            }
        }.runTaskTimer(plugin, 1L, 1L);
    }

    private void setPasted(boolean v) {
        pasted = v;
        YamlConfiguration y = new YamlConfiguration();
        y.set("pasted", v);
        try {
            plugin.getDataFolder().mkdirs();
            y.save(stateFile);
        } catch (IOException ex) {
            plugin.getLogger().warning("Couldn't save arena-state.yml: " + ex);
        }
    }

    void shutdown() {
        if (pasteTask != null) {
            pasteTask.cancel();
            pasteTask = null;
            plugin.getLogger().warning("Arena paste was interrupted by shutdown. Run /ww paste again.");
        }
    }
}
