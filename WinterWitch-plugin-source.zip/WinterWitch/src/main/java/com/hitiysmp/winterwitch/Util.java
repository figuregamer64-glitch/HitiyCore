package com.hitiysmp.winterwitch;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.SoundCategory;
import org.bukkit.World;
import org.bukkit.util.Vector;

final class Util {
    static final Particle.DustOptions ICE = new Particle.DustOptions(Color.fromRGB(150, 225, 255), 1.4f);
    static final Particle.DustOptions RED = new Particle.DustOptions(Color.fromRGB(255, 70, 70), 1.5f);
    static final Particle.DustOptions WHITE = new Particle.DustOptions(Color.fromRGB(245, 250, 255), 1.2f);

    private static final MiniMessage MM = MiniMessage.miniMessage();

    private Util() {
    }

    static Component mm(String s) {
        return MM.deserialize(s);
    }

    /** Plays a sound by its namespaced key so it never breaks on API renames. */
    static void sound(Location l, String key, float vol, float pitch) {
        World w = l.getWorld();
        if (w != null) {
            w.playSound(l, key, SoundCategory.HOSTILE, vol, pitch);
        }
    }

    static double horiz(Location a, Location b) {
        double dx = a.getX() - b.getX();
        double dz = a.getZ() - b.getZ();
        return Math.sqrt(dx * dx + dz * dz);
    }

    static void ring(Location c, double r, int points, Particle p, Object data) {
        World w = c.getWorld();
        if (w == null) {
            return;
        }
        for (int i = 0; i < points; i++) {
            double a = 2 * Math.PI * i / points;
            w.spawnParticle(p, c.getX() + Math.cos(a) * r, c.getY() + 0.15, c.getZ() + Math.sin(a) * r,
                    1, 0, 0, 0, 0, data);
        }
    }

    static void line(Location from, Vector dirUnit, double len, double step, Particle p, Object data) {
        World w = from.getWorld();
        if (w == null) {
            return;
        }
        for (double d = 0; d <= len; d += step) {
            w.spawnParticle(p, from.getX() + dirUnit.getX() * d, from.getY() + dirUnit.getY() * d,
                    from.getZ() + dirUnit.getZ() * d, 1, 0, 0, 0, 0, data);
        }
    }

    /** Distance from point p to the segment starting at a, going along dirUnit for len blocks. */
    static double segDist(Vector p, Vector a, Vector dirUnit, double len) {
        Vector ap = p.clone().subtract(a);
        double t = Math.max(0, Math.min(len, ap.dot(dirUnit)));
        Vector closest = a.clone().add(dirUnit.clone().multiply(t));
        return p.distance(closest);
    }
}
