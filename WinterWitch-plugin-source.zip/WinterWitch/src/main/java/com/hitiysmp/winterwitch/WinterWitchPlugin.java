package com.hitiysmp.winterwitch;

import org.bukkit.NamespacedKey;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Entity;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

public final class WinterWitchPlugin extends JavaPlugin {
    private Items items;
    private BossManager bosses;
    private Arena arena;
    private NamespacedKey roleKey;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        roleKey = new NamespacedKey(this, "role");
        items = new Items(this);
        arena = new Arena(this);
        arena.ensureWorld();
        bosses = new BossManager(this);

        getServer().getPluginManager().registerEvents(new BossListener(this), this);
        getServer().getPluginManager().registerEvents(new ItemListener(this), this);
        getServer().getPluginManager().registerEvents(new ArenaListener(this), this);

        WinterWitchCommand cmd = new WinterWitchCommand(this);
        PluginCommand pc = getCommand("winterwitch");
        if (pc != null) {
            pc.setExecutor(cmd);
            pc.setTabCompleter(cmd);
        }
        getLogger().info("Winter Witch loaded.");
    }

    @Override
    public void onDisable() {
        if (bosses != null) {
            bosses.shutdown();
        }
        if (arena != null) {
            arena.shutdown();
        }
    }

    public void reload() {
        reloadConfig();
        items.reload();
    }

    public Items items() {
        return items;
    }

    public Arena arena() {
        return arena;
    }

    public BossManager bosses() {
        return bosses;
    }

    public NamespacedKey roleKey() {
        return roleKey;
    }

    /** "boss", "decoy", "add" or null. */
    public String roleOf(Entity e) {
        return e.getPersistentDataContainer().get(roleKey, PersistentDataType.STRING);
    }
}
