package com.hitiysmp.winterwitch;

import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

final class Rewards {
    private Rewards() {
    }

    static void distribute(WinterWitchPlugin plugin, WitchBoss fight) {
        Map<UUID, Double> dmg = fight.damageMap();
        double total = 0;
        for (double v : dmg.values()) {
            total += v;
        }
        if (total <= 0) {
            return;
        }
        FileConfiguration c = plugin.getConfig();
        double minShare = c.getDouble("rewards.min-damage-share", 0.03);
        int baseCoins = c.getInt("rewards.coins.base", 16);
        int shareBonus = c.getInt("rewards.coins.share-bonus", 48);
        int topBonus = c.getInt("rewards.coins.top-damage-bonus", 16);
        boolean guaranteed = c.getBoolean("rewards.frostbrand-top-damage-guaranteed", true);
        double swordChance = c.getDouble("rewards.frostbrand-chance", 0.15);
        double armorChance = c.getDouble("rewards.armor-piece-chance", 0.25);
        double sigilChance = c.getDouble("rewards.sigil-chance", 0.35);

        List<Map.Entry<UUID, Double>> sorted = new ArrayList<>(dmg.entrySet());
        sorted.sort((a, b) -> Double.compare(b.getValue(), a.getValue()));
        Random rnd = new Random();
        StringBuilder top = new StringBuilder();
        int rank = 0;
        for (Map.Entry<UUID, Double> en : sorted) {
            rank++;
            double share = en.getValue() / total;
            String name = Bukkit.getOfflinePlayer(en.getKey()).getName();
            if (rank <= 3) {
                if (top.length() > 0) {
                    top.append("<dark_gray> | ");
                }
                top.append("<white>").append(name == null ? "?" : name).append(" <gray>")
                        .append(Math.round(share * 100)).append("%");
            }
            Player p = Bukkit.getPlayer(en.getKey());
            if (p == null || share < minShare) {
                continue;
            }
            int coins = baseCoins + (int) Math.round(share * shareBonus) + (rank == 1 ? topBonus : 0);
            plugin.items().giveCoins(p, coins);
            List<String> loot = new ArrayList<>();
            loot.add("<gold>" + coins + " HitiyCoin");

            if ((rank == 1 && guaranteed) || rnd.nextDouble() < swordChance) {
                plugin.items().giveOrDrop(p, plugin.items().frostbrand());
                loot.add("<aqua>Witch's Frostbrand");
                Bukkit.broadcast(Util.mm("<aqua>\u2744 <white>" + p.getName() + " <gray>claimed the <aqua>Witch's Frostbrand<gray>!"));
            }
            for (String id : plugin.items().armorIds()) {
                if (rnd.nextDouble() < armorChance) {
                    plugin.items().giveOrDrop(p, plugin.items().armorPiece(id));
                    loot.add("<aqua>" + id.replace("frostheart_", "Frostheart ").replace("_", " "));
                    Bukkit.broadcast(Util.mm("<aqua>\u2744 <white>" + p.getName() + " <gray>found a piece of the <aqua>Frostheart <gray>set!"));
                }
            }
            if (rnd.nextDouble() < sigilChance) {
                plugin.items().giveOrDrop(p, plugin.items().sigil());
                loot.add("<aqua>Winter Sigil");
            }
            p.sendMessage(Util.mm("<aqua>\u2744 <white>Loot: " + String.join("<gray>, ", loot)));
            p.showTitle(Title.title(Util.mm("<aqua><bold>VICTORY"), Util.mm("<gray>Rank #" + rank + " - " + Math.round(share * 100) + "% damage"),
                    Title.Times.times(Duration.ofMillis(300), Duration.ofSeconds(4), Duration.ofMillis(800))));
        }
        Bukkit.broadcast(Util.mm("<aqua>\u2744 <gray>Top damage: " + top));
    }
}
