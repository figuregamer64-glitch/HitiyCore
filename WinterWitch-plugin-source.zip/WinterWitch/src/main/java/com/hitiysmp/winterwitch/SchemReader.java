package com.hitiysmp.winterwitch;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.GZIPInputStream;

/** Minimal reader for Sponge schematics (WorldEdit .schem, versions 2 and 3). Block entities are ignored. */
final class SchemReader {
    static final class Schem {
        final int width, height, length;
        /** Palette index per block, ordered x + z*width + y*width*length. */
        final short[] data;
        /** Block state string per palette index (e.g. "minecraft:stone"). */
        final String[] palette;

        Schem(int w, int h, int l, short[] data, String[] palette) {
            this.width = w;
            this.height = h;
            this.length = l;
            this.data = data;
            this.palette = palette;
        }
    }

    private SchemReader() {
    }

    @SuppressWarnings("unchecked")
    static Schem read(File file) throws IOException {
        try (DataInputStream in = new DataInputStream(
                new BufferedInputStream(new GZIPInputStream(new FileInputStream(file), 1 << 16), 1 << 16))) {
            byte type = in.readByte();
            if (type != 10) {
                throw new IOException("Not an NBT compound root");
            }
            in.readUTF();
            Map<String, Object> root = readCompound(in);
            Map<String, Object> s = root.get("Schematic") instanceof Map<?, ?> m ? (Map<String, Object>) m : root;

            int w = ((Number) s.get("Width")).intValue() & 0xFFFF;
            int h = ((Number) s.get("Height")).intValue() & 0xFFFF;
            int l = ((Number) s.get("Length")).intValue() & 0xFFFF;

            Map<String, Object> paletteMap;
            byte[] raw;
            if (s.get("Blocks") instanceof Map<?, ?> blocks) {           // version 3
                paletteMap = (Map<String, Object>) blocks.get("Palette");
                raw = (byte[]) blocks.get("Data");
            } else {                                                      // version 2
                paletteMap = (Map<String, Object>) s.get("Palette");
                raw = (byte[]) s.get("BlockData");
            }
            if (paletteMap == null || raw == null) {
                throw new IOException("Schematic has no block palette/data");
            }
            int max = 0;
            for (Object v : paletteMap.values()) {
                max = Math.max(max, ((Number) v).intValue());
            }
            String[] palette = new String[max + 1];
            for (Map.Entry<String, Object> e : paletteMap.entrySet()) {
                palette[((Number) e.getValue()).intValue()] = e.getKey();
            }

            int total = w * h * l;
            short[] data = new short[total];
            int i = 0;
            int n = 0;
            while (i < raw.length && n < total) {
                int value = 0;
                int shift = 0;
                while (true) {
                    int b = raw[i++] & 0xFF;
                    value |= (b & 0x7F) << shift;
                    if ((b & 0x80) == 0) {
                        break;
                    }
                    shift += 7;
                }
                data[n++] = (short) value;
            }
            if (n != total) {
                throw new IOException("Block data length mismatch: " + n + " vs " + total);
            }
            return new Schem(w, h, l, data, palette);
        }
    }

    // ------------------------------------------------------------------ NBT

    private static Map<String, Object> readCompound(DataInputStream in) throws IOException {
        Map<String, Object> out = new HashMap<>();
        while (true) {
            byte type = in.readByte();
            if (type == 0) {
                return out;
            }
            String name = in.readUTF();
            out.put(name, readPayload(in, type));
        }
    }

    private static Object readPayload(DataInputStream in, byte type) throws IOException {
        switch (type) {
            case 1:
                return in.readByte();
            case 2:
                return in.readShort();
            case 3:
                return in.readInt();
            case 4:
                return in.readLong();
            case 5:
                return in.readFloat();
            case 6:
                return in.readDouble();
            case 7: {
                byte[] a = new byte[in.readInt()];
                in.readFully(a);
                return a;
            }
            case 8:
                return in.readUTF();
            case 9: {
                byte t = in.readByte();
                int len = in.readInt();
                List<Object> list = new ArrayList<>(Math.max(0, Math.min(len, 1024)));
                for (int i = 0; i < len; i++) {
                    list.add(readPayload(in, t));
                }
                return list;
            }
            case 10:
                return readCompound(in);
            case 11: {
                int[] a = new int[in.readInt()];
                for (int i = 0; i < a.length; i++) {
                    a[i] = in.readInt();
                }
                return a;
            }
            case 12: {
                long[] a = new long[in.readInt()];
                for (int i = 0; i < a.length; i++) {
                    a[i] = in.readLong();
                }
                return a;
            }
            default:
                throw new IOException("Unknown NBT tag " + type);
        }
    }
}
