package com.hitiysmp.winterwitch;

import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

public final class BossManager {
    private final WinterWitchPlugin plugin;
    private WitchBoss active;
    private BukkitTask countdown;
    private BukkitTask entering;
    private BukkitTask returning;
    private long lastEndMillis = 0;

    BossManager(WinterWitchPlugin plugin) {
        this.plugin = plugin;
    }

    public WitchBoss active() {
        return active;
    }

    public boolean isBusy() {
        return active != null || countdown != null || entering != null;
    }

    /** Returns null if a fight may start, otherwise the reason it can't. */
    public String blockReason() {
        Arena arena = plugin.arena();
        if (arena.isPasting()) {
            return "The arena is still being built.";
        }
        if (!arena.isReady()) {
            return "The arena isn't built yet. An admin needs to run /ww paste.";
        }
        if (isBusy()) {
            return "The Winter Witch is already stirring.";
        }
        long cdMs = (long) (plugin.getConfig().getDouble("boss.cooldown-minutes", 10) * 60_000L);
        long left = lastEndMillis + cdMs - System.currentTimeMillis();
        if (left > 0) {
            return "The winter needs time to gather again (" + (left / 1000 + 1) + "s).";
        }
        return null;
    }

    /**
     * Opens the Winter Gate at gateLoc. After the countdown everyone nearby is pulled into the arena
     * and the fight begins a few seconds after they arrive.
     */
    public void start(Location gateLoc, Player initiator) {
        final Location c = gateLoc.clone();
        final int secs = plugin.getConfig().getInt("boss.summon-countdown-seconds", 10);
        final double gateRadius = plugin.getConfig().getDouble("arena.gate-radius", 25);
        Bukkit.broadcast(Util.mm("<aqua>\u2744 <white>A frozen gate tears open near <aqua>"
                + c.getBlockX() + ", " + c.getBlockY() + ", " + c.getBlockZ()
                + "<white>... the <aqua>Winter Witch <white>awaits beyond it!"));
        countdown = new BukkitRunnable() {
            int left = secs;

            @Override
            public void run() {
                if (left <= 0) {
                    cancel();
                    countdown = null;
                    pullThrough(c, gateRadius, initiator);
                    return;
                }
                double r = 1.5 + (secs - left) * 0.25;
                Util.ring(c.clone().add(0, 0.2, 0), r, 40, Particle.SNOWFLAKE, null);
                Util.ring(c.clone().add(0, 1.2, 0), r, 40, Particle.END_ROD, null);
                Util.ring(c.clone().add(0, 2.2, 0), r, 40, Particle.SNOWFLAKE, null);
                Util.sound(c, "block.powder_snow.break", 1.5f, 0.6f);
                for (Player p : c.getWorld().getNearbyPlayers(c, 60)) {
                    p.showTitle(Title.title(Util.mm("<aqua>\u2744 " + left),
                            Util.mm("<gray>Stay close to be pulled through the gate"),
                            Title.Times.times(Duration.ZERO, Duration.ofMillis(1100), Duration.ZERO)));
                }
                left--;
            }
        }.runTaskTimer(plugin, 0L, 20L);
    }

    private void pullThrough(Location gate, double gateRadius, Player initiator) {
        List<Player> group = new ArrayList<>();
        for (Player p : gate.getWorld().getNearbyPlayers(gate, gateRadius)) {
            if (p.getGameMode() == GameMode.SURVIVAL || p.getGameMode() == GameMode.ADVENTURE) {
                group.add(p);
            }
        }
        if (initiator != null && initiator.isOnline() && !group.contains(initiator)
                && initiator.getWorld() == gate.getWorld()) {
            group.add(initiator);
        }
        if (group.isEmpty()) {
            Bukkit.broadcast(Util.mm("<aqua>\u2744 <gray>The gate collapses. Nobody was close enough."));
            lastEndMillis = 0;
            return;
        }
        Util.sound(gate, "entity.ender_dragon.growl", 1.5f, 1.4f);
        plugin.arena().sendIn(group);
        // Let everyone arrive and see the crater before the witch appears.
        entering = new BukkitRunnable() {
            @Override
            public void run() {
                entering = null;
                if (plugin.arena().world().getPlayers().isEmpty()) {
                    return;
                }
                active = new WitchBoss(plugin, BossManager.this, plugin.arena().home(), initiator);
                active.start();
            }
        }.runTaskLater(plugin, 80L);
    }

    /** Called by the fight when it is over. */
    void fightEnded(WitchBoss fight, boolean victory) {
        if (active == fight) {
            active = null;
        }
        lastEndMillis = System.currentTimeMillis();
        if (victory) {
            int delay = plugin.getConfig().getInt("arena.return-delay-seconds", 12);
            Arena arena = plugin.arena();
            if (arena.world() != null) {
                for (Player p : arena.world().getPlayers()) {
                    p.sendMessage(Util.mm("<aqua>\u2744 <gray>The gate home opens in <white>" + delay + "s<gray>. Grab your loot."));
                }
            }
            if (returning != null) {
                returning.cancel();
            }
            returning = Bukkit.getScheduler().runTaskLater(plugin, () -> {
                returning = null;
                if (active == null) {
                    plugin.arena().returnAll();
                }
            }, delay * 20L);
        } else {
            plugin.arena().returnAll();
        }
    }

    /** Ends everything without rewards and sends players home. */
    public void stop() {
        if (countdown != null) {
            countdown.cancel();
            countdown = null;
        }
        if (entering != null) {
            entering.cancel();
            entering = null;
        }
        if (returning != null) {
            returning.cancel();
            returning = null;
        }
        if (active != null) {
            active.shutdown();
        } else {
            plugin.arena().returnAll();
        }
    }

    public void shutdown() {
        stop();
    }
}
