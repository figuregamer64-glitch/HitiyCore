package com.hitiysmp.winterwitch;

import org.bukkit.Particle;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

public final class ItemListener implements Listener {
    private static final long COLD_SNAP_COOLDOWN_MS = 30_000L;

    private final WinterWitchPlugin plugin;
    private final Random rnd = new Random();
    private final Map<UUID, Long> coldSnapReady = new HashMap<>();

    ItemListener(WinterWitchPlugin plugin) {
        this.plugin = plugin;
    }

    // ---------------------------------------------------------------- Frostbrand: Chill

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHit(EntityDamageByEntityEvent e) {
        if (!(e.getDamager() instanceof Player p)) {
            return;
        }
        if (!(e.getEntity() instanceof LivingEntity victim) || victim instanceof Player) {
            return;
        }
        ItemStack hand = p.getInventory().getItemInMainHand();
        if (!Items.FROSTBRAND.equals(plugin.items().idOf(hand))) {
            return;
        }
        if (rnd.nextDouble() > 0.25) {
            return;
        }
        victim.setFreezeTicks(victim.getMaxFreezeTicks() + 40);
        victim.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 60, 1, false, true, true));
        victim.getWorld().spawnParticle(Particle.SNOWFLAKE, victim.getLocation().add(0, 1, 0), 25, 0.4, 0.6, 0.4, 0.05);
        Util.sound(victim.getLocation(), "block.glass.break", 0.7f, 1.6f);
    }

    // ---------------------------------------------------------------- Frostbrand: Cold Snap

    @EventHandler(ignoreCancelled = false)
    public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) {
            return;
        }
        Action a = e.getAction();
        if (a != Action.RIGHT_CLICK_AIR && a != Action.RIGHT_CLICK_BLOCK) {
            return;
        }
        Player p = e.getPlayer();
        ItemStack hand = p.getInventory().getItemInMainHand();
        String id = plugin.items().idOf(hand);
        if (id == null) {
            return;
        }
        if (Items.SIGIL.equals(id)) {
            e.setCancelled(true);
            useSigil(p, hand);
            return;
        }
        if (Items.FROSTBRAND.equals(id)) {
            if (e.getClickedBlock() != null && e.getClickedBlock().getType().isInteractable()) {
                return;
            }
            coldSnap(p);
        }
    }

    private void coldSnap(Player p) {
        long now = System.currentTimeMillis();
        long ready = coldSnapReady.getOrDefault(p.getUniqueId(), 0L);
        if (now < ready) {
            p.sendActionBar(Util.mm("<aqua>Cold Snap <gray>ready in <white>" + ((ready - now) / 1000 + 1) + "s"));
            return;
        }
        coldSnapReady.put(p.getUniqueId(), now + COLD_SNAP_COOLDOWN_MS);
        Vector look = p.getLocation().getDirection().setY(0);
        if (look.lengthSquared() < 0.01) {
            return;
        }
        look.normalize();
        for (double d = 1; d <= 7; d += 0.6) {
            double spread = d * 0.45;
            for (int i = -2; i <= 2; i++) {
                Vector side = new Vector(-look.getZ(), 0, look.getX()).multiply(spread * i / 2.0);
                p.getWorld().spawnParticle(Particle.SNOWFLAKE,
                        p.getLocation().add(look.clone().multiply(d)).add(side).add(0, 1.0, 0), 1, 0.1, 0.1, 0.1, 0.02);
            }
        }
        Util.sound(p.getLocation(), "block.glass.break", 1.2f, 0.7f);
        Util.sound(p.getLocation(), "entity.player.hurt_freeze", 1.2f, 0.8f);
        for (Entity ent : p.getNearbyEntities(7, 3, 7)) {
            if (!(ent instanceof LivingEntity le) || ent instanceof Player) {
                continue;
            }
            Vector to = le.getLocation().toVector().subtract(p.getLocation().toVector()).setY(0);
            if (to.lengthSquared() < 0.01 || to.normalize().dot(look) < 0.35) {
                continue;
            }
            le.setFreezeTicks(le.getMaxFreezeTicks() + 60);
            le.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 80, 2, false, true, true));
            le.damage(9, p);
        }
        p.addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION, 160, 1, false, true, true));
    }

    // ---------------------------------------------------------------- Winter Sigil

    private void useSigil(Player p, ItemStack hand) {
        if (!p.hasPermission("winterwitch.summon")) {
            p.sendActionBar(Util.mm("<red>You can't use that."));
            return;
        }
        String reason = plugin.bosses().blockReason();
        if (reason != null) {
            p.sendActionBar(Util.mm("<red>" + reason));
            return;
        }
        hand.setAmount(hand.getAmount() - 1);
        plugin.bosses().start(p.getLocation(), p);
    }

    // ---------------------------------------------------------------- Frostheart set bonus

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onFreeze(EntityDamageEvent e) {
        if (e.getCause() == EntityDamageEvent.DamageCause.FREEZE
                && e.getEntity() instanceof Player p && plugin.items().fullSet(p)) {
            e.setCancelled(true);
            p.setFreezeTicks(0);
        }
    }
}
