package com.hitiysmp.winterwitch;

import com.destroystokyo.paper.entity.Pathfinder;
import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.FluidCollisionMode;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.block.Block;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Stray;
import org.bukkit.entity.Witch;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;
import net.kyori.adventure.text.format.NamedTextColor;

import java.time.Duration;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/**
 * One Winter Witch fight. The boss is a scaled-up Witch with vanilla goals removed; every decision
 * is made here: target choice, positioning, ability selection, and counters to player strategies.
 */
public final class WitchBoss {
    /** Real entity health pool. Damage is scaled so the effective HP can be anything. */
    public static final double POOL = 1024.0;
    private static final String TEAM = "ww_boss";

    private final WinterWitchPlugin plugin;
    private final BossManager manager;
    private final World world;
    private final Location home;
    private final Random rnd = new Random();
    private final double radius;
    private final double effectiveMax;
    private final long enrageTick;

    private Witch boss;
    private BossBar bar;
    private BukkitTask task;

    private long tick = 0;
    private int phase = 1;
    private boolean ended = false;
    private boolean enraged = false;
    private boolean deathHandled = false;
    private boolean prevStorm;

    private long castStart, castUntil, gcdUntil, invulnUntil, barrierUntil, zonesMoveAt, noFighterTicks;
    private Runnable castEffect, castTelegraph;
    private int mirrorStage = 0, noLosTicks = 0, unreachableTicks = 0, strafeSign = 1;
    private Player currentTarget;

    private final Map<UUID, Double> totalDamage = new HashMap<>();
    private final Map<UUID, Double> threat = new HashMap<>();
    private final Map<UUID, Location> lastPos = new HashMap<>();
    private final Map<UUID, Vector> vel = new HashMap<>();
    private final Map<String, Long> cd = new HashMap<>();
    private final Deque<double[]> hits = new ArrayDeque<>();
    private final List<LivingEntity> adds = new ArrayList<>();
    private final Map<LivingEntity, Long> decoys = new HashMap<>();
    private final List<Location> zones = new ArrayList<>();
    private double zoneRadius = 5;

    WitchBoss(WinterWitchPlugin plugin, BossManager manager, Location home, Player initiator) {
        this.plugin = plugin;
        this.manager = manager;
        this.world = home.getWorld();
        this.home = home.clone();
        FileConfiguration c = plugin.getConfig();
        this.radius = plugin.arena().radius();
        int n = 0;
        for (Player p : world.getPlayers()) {
            if (eligible(p) && p.getLocation().distanceSquared(home) <= radius * radius * 1.5) {
                n++;
            }
        }
        n = Math.max(1, n);
        double hp = c.getDouble("boss.base-health", 1500) + c.getDouble("boss.health-per-extra-player", 600) * (n - 1);
        this.effectiveMax = Math.max(200, Math.min(hp, c.getDouble("boss.max-health", 8000)));
        this.enrageTick = (long) (c.getDouble("boss.enrage-seconds", 480) * 20);
    }

    // =================================================================== lifecycle

    void start() {
        prevStorm = world.hasStorm();
        if (plugin.getConfig().getBoolean("boss.weather", true)) {
            world.setStorm(true);
        }
        Location spawn = findSafe(home);
        if (spawn == null) {
            spawn = home.clone();
        }
        boss = world.spawn(spawn, Witch.class, w -> {
            w.getPersistentDataContainer().set(plugin.roleKey(), PersistentDataType.STRING, "boss");
            w.customName(Util.mm("<aqua><bold>Winter Witch"));
            w.setCustomNameVisible(true);
            w.setRemoveWhenFarAway(false);
            w.setPersistent(false);
            w.setCanPickupItems(false);
            setBase(w, Attribute.MAX_HEALTH, POOL);
            w.setHealth(POOL);
            setBase(w, Attribute.SCALE, 1.5);
            setBase(w, Attribute.MOVEMENT_SPEED, 0.32);
            setBase(w, Attribute.KNOCKBACK_RESISTANCE, 1.0);
            setBase(w, Attribute.FOLLOW_RANGE, 64);
            setBase(w, Attribute.STEP_HEIGHT, 1.0);
            w.setGlowing(true);
        });
        Bukkit.getMobGoals().removeAllGoals(boss);
        glowTeam(boss);

        bar = BossBar.bossBar(Util.mm("<aqua><bold>Winter Witch"), 1f, BossBar.Color.BLUE, BossBar.Overlay.NOTCHED_10);
        Location bl = boss.getLocation();
        Util.sound(bl, "entity.wither.spawn", 2f, 0.7f);
        Util.sound(bl, "entity.lightning_bolt.thunder", 2f, 0.8f);
        world.spawnParticle(Particle.SNOWFLAKE, bl.clone().add(0, 1.5, 0), 200, 2, 2, 2, 0.2);
        for (Player p : fighters()) {
            p.showTitle(Title.title(Util.mm("<aqua><bold>THE WINTER WITCH"),
                    Util.mm("<gray>Stay together. Stay warm."),
                    Title.Times.times(Duration.ofMillis(400), Duration.ofSeconds(3), Duration.ofMillis(800))));
        }
        invulnUntil = 100;
        task = new BukkitRunnable() {
            @Override
            public void run() {
                tick += 2;
                try {
                    loop();
                } catch (Throwable t) {
                    plugin.getLogger().log(java.util.logging.Level.WARNING, "Winter Witch loop error", t);
                }
            }
        }.runTaskTimer(plugin, 2L, 2L);
    }

    private void end(boolean victory) {
        if (ended) {
            return;
        }
        ended = true;
        if (task != null) {
            task.cancel();
        }
        if (bar != null) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                p.hideBossBar(bar);
            }
        }
        for (LivingEntity e : new ArrayList<>(adds)) {
            e.remove();
        }
        for (LivingEntity e : new ArrayList<>(decoys.keySet())) {
            e.remove();
        }
        adds.clear();
        decoys.clear();
        if (!victory && boss != null && boss.isValid()) {
            boss.remove();
        }
        Team t = Bukkit.getScoreboardManager().getMainScoreboard().getTeam(TEAM);
        if (t != null) {
            try {
                t.unregister();
            } catch (IllegalStateException ignored) {
                // already gone
            }
        }
        if (plugin.getConfig().getBoolean("boss.weather", true)) {
            world.setStorm(prevStorm);
        }
        manager.fightEnded(this, victory);
    }

    /** Ends the fight with no rewards (admin stop, plugin disable, retreat). */
    public void shutdown() {
        end(false);
    }

    public void onBossDeath() {
        if (deathHandled) {
            return;
        }
        deathHandled = true;
        Location l = boss.getLocation();
        Util.sound(l, "entity.ender_dragon.death", 2f, 1.2f);
        Util.sound(l, "block.beacon.deactivate", 2f, 0.7f);
        world.spawnParticle(Particle.END_ROD, l.clone().add(0, 1.5, 0), 300, 2.5, 2.5, 2.5, 0.25);
        world.spawnParticle(Particle.SNOWFLAKE, l.clone().add(0, 1.5, 0), 300, 3, 3, 3, 0.3);
        Bukkit.broadcast(Util.mm("<aqua>\u2744 <white>The <aqua>Winter Witch <white>has fallen. Spring returns..."));
        Rewards.distribute(plugin, this);
        end(true);
    }

    // =================================================================== queries for listeners

    public Witch boss() {
        return boss;
    }

    public boolean isBoss(Entity e) {
        return boss != null && e.getUniqueId().equals(boss.getUniqueId());
    }

    public boolean isDecoy(Entity e) {
        return e instanceof LivingEntity le && decoys.containsKey(le);
    }

    public double damageFactor() {
        return POOL / effectiveMax;
    }

    public boolean isInvulnerable() {
        return tick < invulnUntil;
    }

    public boolean barrierUp() {
        return tick < barrierUntil;
    }

    public int phase() {
        return phase;
    }

    public boolean enraged() {
        return enraged;
    }

    public double effectiveMax() {
        return effectiveMax;
    }

    public double currentHp() {
        return boss == null ? 0 : boss.getHealth() / POOL * effectiveMax;
    }

    public Map<UUID, Double> damageMap() {
        return totalDamage;
    }

    public void recordDamage(Player p, double amount, boolean projectile) {
        totalDamage.merge(p.getUniqueId(), amount, Double::sum);
        threat.merge(p.getUniqueId(), amount, Double::sum);
        hits.addLast(new double[]{tick, amount, projectile ? 1 : 0});
    }

    public void deflect() {
        Location l = boss.getLocation().add(0, 1.5, 0);
        Util.sound(l, "block.amethyst_block.chime", 1.2f, 1.9f);
        world.spawnParticle(Particle.END_ROD, l, 12, 0.9, 1.1, 0.9, 0.05);
    }

    public void shatterDecoy(LivingEntity d, Player by) {
        Location l = d.getLocation();
        decoys.remove(d);
        d.remove();
        world.spawnParticle(Particle.SNOWFLAKE, l.clone().add(0, 1.5, 0), 80, 1, 1.2, 1, 0.15);
        Util.sound(l, "block.glass.break", 1.5f, 0.8f);
        for (Player p : fighters()) {
            if (p.getLocation().distanceSquared(l) <= 4.5 * 4.5) {
                hurt(p, 6);
                slow(p, 1, 50);
            }
        }
        if (by != null) {
            by.sendActionBar(Util.mm("<gray>A mirror image shatters - <red>that was not the real witch."));
        }
    }

    // =================================================================== main loop

    private void loop() {
        if (ended) {
            return;
        }
        if (boss == null || !boss.isValid() || boss.isDead()) {
            if (!deathHandled) {
                end(false);
            }
            return;
        }
        List<Player> fighters = fighters();
        updateBar();
        Location bl = boss.getLocation();
        world.spawnParticle(Particle.SNOWFLAKE, bl.clone().add(0, 1.6, 0), 8, 0.7, 1.0, 0.7, 0.02);
        if (tick < invulnUntil) {
            world.spawnParticle(Particle.END_ROD, bl.clone().add(0, 1.5, 0), 6, 1.0, 1.4, 1.0, 0.02);
        }
        if (tick < barrierUntil) {
            Util.ring(bl.clone().add(0, 0.8, 0), 1.8, 14, Particle.END_ROD, null);
            Util.ring(bl.clone().add(0, 2.0, 0), 1.6, 14, Particle.CLOUD, null);
        }
        if (bl.distanceSquared(home) > (radius + 12) * (radius + 12)) {
            Location back = findSafe(home);
            boss.teleport(back != null ? back : home);
        }
        if (fighters.isEmpty()) {
            noFighterTicks += 2;
            long limit = (long) (plugin.getConfig().getInt("boss.reset-no-player-seconds", 30) * 20);
            if (noFighterTicks > limit) {
                Bukkit.broadcast(Util.mm("<aqua>\u2744 <gray>The Winter Witch retreats into the blizzard, unchallenged."));
                end(false);
            }
            return;
        }
        noFighterTicks = 0;

        upkeepDecoys();
        decayThreat();

        double ratio = boss.getHealth() / POOL;
        int np = ratio > 0.70 ? 1 : ratio > 0.35 ? 2 : 3;
        if (np > phase) {
            transition(np, fighters);
        }
        if (!enraged && tick >= enrageTick) {
            enrage(fighters);
        }

        if (phase >= 2 || enraged) {
            if (tick % 20 == 0) {
                applyCold(fighters);
            }
            if (tick % 4 == 0) {
                renderZones();
            }
            if (!enraged && tick >= zonesMoveAt && tick >= invulnUntil) {
                for (Player p : fighters) {
                    p.sendActionBar(Util.mm("<gold>The warmth drifts... <gray>move to the new warm zones!"));
                }
                setupZones();
            }
        }

        if (castEffect != null) {
            if (tick >= castUntil) {
                Runnable r = castEffect;
                castEffect = null;
                castTelegraph = null;
                r.run();
            } else if (castTelegraph != null) {
                castTelegraph.run();
            }
            return;
        }
        if (tick < invulnUntil) {
            return;
        }
        if (tick % 10 == 0) {
            think(fighters);
        }
    }

    // =================================================================== decision making

    private void think(List<Player> fighters) {
        adds.removeIf(e -> !e.isValid());
        sampleMovement(fighters);

        Player target = pickTarget(fighters);
        if (target == null) {
            return;
        }
        currentTarget = target;
        Location bl = boss.getLocation();
        Location tl = target.getLocation();
        double dist = bl.getWorld() == tl.getWorld() ? bl.distance(tl) : 999;
        boolean los = boss.hasLineOfSight(target);
        noLosTicks = los ? 0 : noLosTicks + 10;
        boolean canReach = false;
        try {
            Pathfinder.PathResult pr = boss.getPathfinder().findPath(target);
            canReach = pr != null;
        } catch (Throwable ignored) {
            canReach = true;
        }
        unreachableTicks = canReach ? 0 : unreachableTicks + 10;

        boss.lookAt(target.getEyeLocation());

        if (tick >= gcdUntil && castEffect == null) {
            double ratio = boss.getHealth() / POOL;
            // 1. Counter ranged spam with a projectile-proof barrier.
            if (ready("barrier") && projectileHeavy()) {
                castBarrier(fighters);
                return;
            }
            // 2. Phase 3: split into mirror images (again near death).
            if (phase == 3 && ready("mirror") && (mirrorStage == 0 || (mirrorStage == 1 && ratio <= 0.12))) {
                castMirror();
                return;
            }
            // 3. Counter kiting: drag far-away players back in.
            if (phase >= 2 && ready("grasp") && farFraction(fighters) >= 0.5) {
                castGrasp();
                return;
            }
            // 4. Punish people standing on top of her.
            if (ready("nova") && anyoneWithin(fighters, 5.5)) {
                castNova();
                return;
            }
            // 5. Counter hiding behind walls / pillar-poling / being glued to her.
            if (ready("blink") && (noLosTicks >= 60 || unreachableTicks >= 40 || (dist < 3.0 && !ready("nova")))) {
                blink(target);
                return;
            }
            if (phase >= 2 && ready("thralls") && adds.size() < 6) {
                castThralls(fighters);
                return;
            }
            if (ready("meteor") && (phase == 1 || rnd.nextDouble() < 0.7 || unreachableTicks >= 20)) {
                castMeteors(fighters, phase >= 2 && rnd.nextDouble() < 0.65);
                return;
            }
            if (ready("lance") && dist <= 36 && (los || dist < 20)) {
                castLance(target);
                return;
            }
        }
        move(target, dist, los);
    }

    private Player pickTarget(List<Player> fighters) {
        Player best = null;
        double bestScore = -1;
        for (Player p : fighters) {
            double d = boss.getLocation().distance(p.getLocation());
            double score = 1.0;
            score += threat.getOrDefault(p.getUniqueId(), 0.0) / (POOL * 0.02);
            score += Math.max(0, (35 - d) / 35.0) * 0.8;
            if (boss.hasLineOfSight(p)) {
                score += 0.5;
            }
            if (p.getHealth() < 8) {
                score += 1.0;
            }
            if (isStationary(p)) {
                score += 1.2;
            }
            if (p.equals(currentTarget)) {
                score += 0.8;
            }
            score += rnd.nextDouble() * 0.6;
            if (score > bestScore) {
                bestScore = score;
                best = p;
            }
        }
        return best;
    }

    private void move(Player target, double dist, boolean los) {
        Pathfinder pf = boss.getPathfinder();
        Location bl = boss.getLocation();
        Location tl = target.getLocation();
        double desired = phase == 1 ? 11 : phase == 2 ? 9 : 7;
        Vector dir = tl.toVector().subtract(bl.toVector()).setY(0);
        if (dir.lengthSquared() < 0.01) {
            dir = new Vector(1, 0, 0);
        }
        dir.normalize();
        if (dist < desired - 3) {
            Location dest = findSafe(bl.clone().add(dir.clone().multiply(-6)));
            if (dest != null && dest.distanceSquared(home) <= radius * radius) {
                pf.moveTo(dest, 1.2);
                return;
            }
        }
        if (dist > desired + 4 || !los) {
            pf.moveTo(tl, 1.0);
            return;
        }
        if (rnd.nextInt(4) == 0) {
            strafeSign = -strafeSign;
        }
        Vector perp = new Vector(-dir.getZ(), 0, dir.getX()).multiply(4 * strafeSign);
        Location dest = findSafe(bl.clone().add(perp));
        if (dest != null && dest.distanceSquared(home) <= radius * radius) {
            pf.moveTo(dest, 0.9);
        }
    }

    // =================================================================== abilities

    private void startCast(String name, int windup, Runnable telegraph, Runnable effect) {
        castStart = tick;
        castUntil = tick + windup;
        castTelegraph = telegraph;
        castEffect = effect;
        gcdUntil = tick + windup + (phase == 3 ? 24 : 40);
        boss.getPathfinder().stopPathfinding();
        boss.swingMainHand();
        Util.sound(boss.getLocation(), "entity.evoker.prepare_summon", 1.2f, 1.4f);
        for (Player p : fighters()) {
            p.sendActionBar(Util.mm("<aqua>\u26A0 <white>" + name));
        }
    }

    private void castLance(Player target) {
        Location from = boss.getEyeLocation();
        Location aim = predict(target, 16).add(0, 1.0, 0);
        Vector dir = aim.toVector().subtract(from.toVector());
        if (dir.lengthSquared() < 0.01) {
            return;
        }
        dir.normalize();
        double max = 38;
        RayTraceResult rr = world.rayTraceBlocks(from, dir, max, FluidCollisionMode.NEVER, true);
        final double len = rr == null ? max : Math.max(2, rr.getHitPosition().distance(from.toVector()));
        final Vector d = dir;
        boss.lookAt(aim);
        setCd("lance", phase == 1 ? 70 : 55);
        startCast("Ice Lance", 16,
                () -> Util.line(from, d, len, 0.8, Particle.DUST, Util.RED),
                () -> {
                    Util.line(from, d, len, 0.3, Particle.END_ROD, null);
                    Util.sound(from, "item.trident.thunder", 1.3f, 1.6f);
                    Vector a = from.toVector();
                    for (Player p : fighters()) {
                        if (Util.segDist(p.getLocation().add(0, 1, 0).toVector(), a, d, len) <= 1.4) {
                            hurt(p, 8);
                            slow(p, 1, 60);
                            p.setFreezeTicks(Math.min(p.getMaxFreezeTicks(), p.getFreezeTicks() + 60));
                        }
                    }
                });
    }

    private void castNova() {
        final Location c = boss.getLocation().clone();
        final double r = phase == 3 ? 8.5 : 7.0;
        setCd("nova", meleeHeavy() ? 110 : 170);
        startCast("Frost Nova", 24,
                () -> {
                    double prog = Math.min(1.0, (tick - castStart) / 24.0);
                    Util.ring(c, r, 48, Particle.DUST, Util.RED);
                    Util.ring(c, r * prog, 32, Particle.SNOWFLAKE, null);
                },
                () -> {
                    for (int i = 1; i <= 4; i++) {
                        Util.ring(c, r * i / 4.0, 40, Particle.CLOUD, null);
                    }
                    world.spawnParticle(Particle.EXPLOSION, c.clone().add(0, 1, 0), 3, 1, 0.5, 1, 0);
                    Util.sound(c, "block.glass.break", 2f, 0.6f);
                    Util.sound(c, "entity.generic.explode", 1.2f, 1.4f);
                    for (Player p : fighters()) {
                        Location pl = p.getLocation();
                        if (Util.horiz(pl, c) <= r && Math.abs(pl.getY() - c.getY()) <= 4) {
                            hurt(p, 10);
                            slow(p, 2, 40);
                            p.setFreezeTicks(Math.min(p.getMaxFreezeTicks(), p.getFreezeTicks() + 100));
                            Vector v = pl.toVector().subtract(c.toVector()).setY(0);
                            if (v.lengthSquared() < 0.01) {
                                v = new Vector(1, 0, 0);
                            }
                            p.setVelocity(v.normalize().multiply(1.3).setY(0.55));
                        }
                    }
                });
    }

    private void castMeteors(List<Player> fighters, boolean big) {
        int n = big ? Math.min(6, 1 + (fighters.size() + 1) / 2 + (phase == 3 ? 1 : 0))
                : Math.min(9, 3 + fighters.size());
        final double r = big ? 3.6 : 2.2;
        final int windup = big ? (phase == 3 ? 32 : 40) : 26;
        final double dmg = big ? 13 : 6;
        List<Player> order = new ArrayList<>(fighters);
        // Stationary players (campers, people sitting in warm zones) get targeted first.
        order.sort(Comparator.comparingDouble(p -> -((isStationary(p) ? 2 : 0) + (inZone(p) ? 1 : 0) + rnd.nextDouble())));
        final List<Location> targets = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            Player p = order.get(i % order.size());
            Location base = predict(p, windup);
            if (i >= order.size()) {
                base.add((rnd.nextDouble() - 0.5) * 7, 0, (rnd.nextDouble() - 0.5) * 7);
            }
            targets.add(base);
        }
        setCd("meteor", big ? 280 : 240);
        startCast(big ? "Glacier Fall" : "Hailstorm", windup,
                () -> {
                    double prog = Math.min(1.0, (tick - castStart) / (double) windup);
                    for (Location t : targets) {
                        Util.ring(t, r, 24, Particle.DUST, Util.RED);
                        Util.ring(t, Math.max(0.3, r * (1 - prog)), 16, Particle.SNOWFLAKE, null);
                        world.spawnParticle(Particle.END_ROD, t.clone().add(0, (1 - prog) * 14, 0), 3, 0.15, 0.4, 0.15, 0.0);
                    }
                },
                () -> {
                    for (Location t : targets) {
                        world.spawnParticle(Particle.EXPLOSION, t.clone().add(0, 0.5, 0), 1);
                        world.spawnParticle(Particle.SNOWFLAKE, t.clone().add(0, 0.5, 0), 60, r * 0.4, 0.6, r * 0.4, 0.15);
                        Util.sound(t, "entity.generic.explode", 0.9f, 1.5f);
                        Util.sound(t, "block.glass.break", 1.0f, 1.0f);
                    }
                    for (Player p : fighters()) {
                        Location pl = p.getLocation();
                        for (Location t : targets) {
                            if (Util.horiz(pl, t) <= r && Math.abs(pl.getY() - t.getY()) <= 3.5) {
                                hurt(p, dmg);
                                slow(p, 1, 60);
                                p.setVelocity(new Vector(0, 0.55, 0));
                                break;
                            }
                        }
                    }
                });
    }

    private void castBarrier(List<Player> fighters) {
        barrierUntil = tick + 120;
        setCd("barrier", 520);
        gcdUntil = tick + 20;
        Util.sound(boss.getLocation(), "block.beacon.activate", 1.5f, 1.6f);
        for (Player p : fighters) {
            p.sendActionBar(Util.mm("<aqua>She conjures a frost barrier - <white>arrows and tridents bounce off! Fight up close."));
        }
    }

    private void castGrasp() {
        final Location c = boss.getLocation().clone().add(0, 1.5, 0);
        setCd("grasp", 360);
        startCast("Winter's Grasp", 24,
                () -> {
                    for (Player p : fighters()) {
                        Location pl = p.getLocation().add(0, 1, 0);
                        double d = pl.distance(c);
                        if (d > 12) {
                            Util.line(c, pl.toVector().subtract(c.toVector()).normalize(), d, 1.0, Particle.CLOUD, null);
                        }
                    }
                },
                () -> {
                    Util.sound(c, "entity.ender_dragon.growl", 1.2f, 1.5f);
                    for (Player p : fighters()) {
                        double d = p.getLocation().distance(c);
                        if (d > 12) {
                            hurt(p, 5);
                            Vector v = c.toVector().subtract(p.getLocation().toVector()).setY(0);
                            if (v.lengthSquared() > 0.01) {
                                p.setVelocity(v.normalize().multiply(Math.min(2.4, 0.5 + d * 0.07)).setY(0.5));
                            }
                            slow(p, 2, 40);
                        }
                    }
                });
    }

    private void castThralls(List<Player> fighters) {
        final int count = Math.min(5, 2 + fighters.size() / 2 + (phase == 3 ? 1 : 0));
        final Location c = boss.getLocation().clone();
        setCd("thralls", 560);
        startCast("Summon Thralls", 24,
                () -> Util.ring(c, 4, 24, Particle.SOUL_FIRE_FLAME, null),
                () -> {
                    Util.sound(c, "entity.evoker.cast_spell", 1.4f, 0.8f);
                    List<Player> now = fighters();
                    for (int i = 0; i < count; i++) {
                        Location spot = findSafe(c.clone().add((rnd.nextDouble() - 0.5) * 10, 0, (rnd.nextDouble() - 0.5) * 10));
                        if (spot == null) {
                            spot = c.clone();
                        }
                        final Player victim = now.isEmpty() ? null : now.get(rnd.nextInt(now.size()));
                        Stray s = world.spawn(spot, Stray.class, st -> {
                            st.getPersistentDataContainer().set(plugin.roleKey(), PersistentDataType.STRING, "add");
                            st.customName(Util.mm("<aqua>Frost Thrall"));
                            st.setRemoveWhenFarAway(false);
                            st.setPersistent(false);
                            setBase(st, Attribute.MAX_HEALTH, 30);
                            st.setHealth(30);
                            if (victim != null) {
                                st.setTarget(victim);
                            }
                        });
                        adds.add(s);
                        world.spawnParticle(Particle.POOF, spot.clone().add(0, 1, 0), 15, 0.4, 0.6, 0.4, 0.05);
                    }
                });
    }

    private void castMirror() {
        mirrorStage++;
        setCd("mirror", 600);
        final Location c = boss.getLocation().clone();
        startCast("Mirror Images", 30,
                () -> Util.ring(c, 2.5, 20, Particle.END_ROD, null),
                () -> {
                    List<Location> slots = new ArrayList<>();
                    double offset = rnd.nextDouble() * Math.PI;
                    for (int i = 0; i < 4; i++) {
                        double a = offset + Math.PI * 2 * i / 4;
                        Location s = findSafe(home.clone().add(Math.cos(a) * 10, 0, Math.sin(a) * 10));
                        slots.add(s != null ? s : home.clone());
                    }
                    Collections.shuffle(slots, rnd);
                    Location real = slots.remove(0);
                    world.spawnParticle(Particle.POOF, boss.getLocation().add(0, 1.5, 0), 40, 0.6, 1, 0.6, 0.05);
                    boss.teleport(real);
                    world.spawnParticle(Particle.POOF, real.clone().add(0, 1.5, 0), 40, 0.6, 1, 0.6, 0.05);
                    Util.sound(real, "entity.enderman.teleport", 1.5f, 0.6f);
                    for (Location s : slots) {
                        spawnDecoy(s);
                    }
                    for (Player p : fighters()) {
                        p.sendActionBar(Util.mm("<aqua>Which one is real? <gray>The true witch's frost aura never fades."));
                    }
                });
    }

    private void spawnDecoy(Location loc) {
        Witch d = world.spawn(loc, Witch.class, w -> {
            w.getPersistentDataContainer().set(plugin.roleKey(), PersistentDataType.STRING, "decoy");
            w.customName(Util.mm("<aqua><bold>Winter Witch"));
            w.setCustomNameVisible(true);
            w.setRemoveWhenFarAway(false);
            w.setPersistent(false);
            setBase(w, Attribute.MAX_HEALTH, 2);
            w.setHealth(2);
            setBase(w, Attribute.SCALE, 1.5);
            w.setAI(false);
            w.setSilent(true);
            w.setCollidable(false);
            w.setGlowing(true);
        });
        glowTeam(d);
        decoys.put(d, tick + 600);
    }

    private void upkeepDecoys() {
        for (LivingEntity d : new ArrayList<>(decoys.keySet())) {
            if (!d.isValid()) {
                decoys.remove(d);
                continue;
            }
            if (tick >= decoys.get(d)) {
                world.spawnParticle(Particle.POOF, d.getLocation().add(0, 1.5, 0), 25, 0.5, 0.8, 0.5, 0.04);
                decoys.remove(d);
                d.remove();
                continue;
            }
            if (tick % 10 == 0) {
                // Decoys only give off a faint puff, never the constant snowflake aura of the real witch.
                world.spawnParticle(Particle.CLOUD, d.getLocation().add(0, 1.5, 0), 3, 0.4, 0.6, 0.4, 0.01);
            }
        }
    }

    private void blink(Player t) {
        boolean near = noLosTicks >= 60 || unreachableTicks >= 40;
        Location dest = null;
        for (int i = 0; i < 14 && dest == null; i++) {
            double a = rnd.nextDouble() * Math.PI * 2;
            double r = near ? 3.5 + rnd.nextDouble() * 2 : 9 + rnd.nextDouble() * 4;
            Location cand = findSafe(t.getLocation().clone().add(Math.cos(a) * r, 0, Math.sin(a) * r));
            if (cand != null && cand.distanceSquared(home) <= radius * radius
                    && cand.distanceSquared(t.getLocation()) > 9) {
                dest = cand;
            }
        }
        if (dest == null) {
            return;
        }
        world.spawnParticle(Particle.POOF, boss.getLocation().add(0, 1.5, 0), 30, 0.5, 1, 0.5, 0.05);
        boss.teleport(dest);
        world.spawnParticle(Particle.SNOWFLAKE, dest.clone().add(0, 1.5, 0), 40, 0.5, 1, 0.5, 0.1);
        Util.sound(dest, "entity.enderman.teleport", 1.5f, 1.4f);
        boss.lookAt(t.getEyeLocation());
        setCd("blink", 140);
        gcdUntil = tick + 14;
        noLosTicks = 0;
        unreachableTicks = 0;
    }

    // =================================================================== phases, cold, enrage

    private void transition(int np, List<Player> fighters) {
        phase = np;
        invulnUntil = tick + 80;
        castEffect = null;
        castTelegraph = null;
        boss.getPathfinder().stopPathfinding();
        final Location bl = boss.getLocation().clone();
        Util.sound(bl, "entity.ender_dragon.growl", 2f, 0.8f);
        Util.sound(bl, "entity.lightning_bolt.thunder", 2f, 0.7f);
        String t1 = np == 2 ? "<aqua><bold>THE BLIZZARD AWAKENS" : "<white><bold>WHITEOUT";
        String t2 = np == 2 ? "<gray>Stay in the warm zones. She calls thralls."
                : "<gray>Find the real witch. Never stand in the open.";
        for (Player p : fighters) {
            p.showTitle(Title.title(Util.mm(t1), Util.mm(t2),
                    Title.Times.times(Duration.ofMillis(300), Duration.ofSeconds(3), Duration.ofMillis(500))));
            Vector v = p.getLocation().toVector().subtract(bl.toVector()).setY(0);
            if (v.lengthSquared() < 0.01) {
                v = new Vector(1, 0, 0);
            }
            p.setVelocity(v.normalize().multiply(1.2).setY(0.4));
        }
        new BukkitRunnable() {
            int i = 0;

            @Override
            public void run() {
                if (i > 8 || ended) {
                    cancel();
                    return;
                }
                Util.ring(bl, 2 + i * 1.8, 40 + i * 6, Particle.SNOWFLAKE, null);
                i++;
            }
        }.runTaskTimer(plugin, 0L, 3L);
        bar.color(np == 2 ? BossBar.Color.PURPLE : BossBar.Color.RED);
        setupZones();
        cd.put("thralls", tick + 100);
        cd.put("meteor", tick + 120);
    }

    private void enrage(List<Player> fighters) {
        enraged = true;
        zones.clear();
        bar.color(BossBar.Color.WHITE);
        Util.sound(boss.getLocation(), "entity.wither.spawn", 2f, 0.5f);
        for (Player p : fighters) {
            p.showTitle(Title.title(Util.mm("<red><bold>ENRAGED"), Util.mm("<gray>The warmth is gone. Finish her!"),
                    Title.Times.times(Duration.ofMillis(300), Duration.ofSeconds(3), Duration.ofMillis(500))));
        }
    }

    private void setupZones() {
        zones.clear();
        zoneRadius = phase == 2 ? 5.0 : 4.0;
        int count = phase == 2 ? 3 : 2;
        for (int i = 0; i < count; i++) {
            for (int tries = 0; tries < 12; tries++) {
                double a = rnd.nextDouble() * Math.PI * 2;
                double d = 6 + rnd.nextDouble() * (radius * 0.6 - 6);
                Location z = findSafe(home.clone().add(Math.cos(a) * d, 0, Math.sin(a) * d));
                if (z != null) {
                    zones.add(z);
                    break;
                }
            }
        }
        zonesMoveAt = tick + 560;
    }

    private void renderZones() {
        for (Location z : zones) {
            Util.ring(z, zoneRadius, 28, Particle.FLAME, null);
            world.spawnParticle(Particle.END_ROD, z.clone().add(0, 1.2, 0), 2, 0.2, 0.9, 0.2, 0.01);
        }
    }

    private boolean inZone(Player p) {
        Location pl = p.getLocation();
        for (Location z : zones) {
            if (Util.horiz(pl, z) <= zoneRadius && Math.abs(pl.getY() - z.getY()) <= 4) {
                return true;
            }
        }
        return false;
    }

    private void applyCold(List<Player> fighters) {
        for (Player p : fighters) {
            if (plugin.items().fullSet(p)) {
                continue;
            }
            int max = p.getMaxFreezeTicks();
            if (!enraged && inZone(p)) {
                p.setFreezeTicks(Math.max(0, p.getFreezeTicks() - 70));
            } else {
                int f = Math.min(max + 20, p.getFreezeTicks() + 34);
                p.setFreezeTicks(f);
                if (f >= max) {
                    hurt(p, 2.0);
                    p.sendActionBar(Util.mm("<aqua>You're freezing! <gray>Get into a warm zone."));
                }
            }
        }
    }

    // =================================================================== reading the players

    private void sampleMovement(List<Player> fighters) {
        for (Player p : fighters) {
            Location now = p.getLocation();
            Location prev = lastPos.put(p.getUniqueId(), now);
            if (prev != null && prev.getWorld() == now.getWorld()) {
                vel.put(p.getUniqueId(), now.toVector().subtract(prev.toVector()).multiply(0.1));
            } else {
                vel.put(p.getUniqueId(), new Vector());
            }
        }
    }

    private boolean isStationary(Player p) {
        Vector v = vel.get(p.getUniqueId());
        return v != null && v.length() * 10 < 0.8;
    }

    /** Where the player will likely be in ticksAhead ticks, based on observed velocity. */
    private Location predict(Player p, int ticksAhead) {
        Location l = p.getLocation().clone();
        Vector v = vel.get(p.getUniqueId());
        if (v != null) {
            Vector off = v.clone().multiply(ticksAhead * 0.9);
            off.setY(0);
            if (off.length() > 14) {
                off.normalize().multiply(14);
            }
            l.add(off);
        }
        return l;
    }

    private boolean projectileHeavy() {
        double[] s = recentHits();
        return s[0] >= POOL * 0.025 && s[1] / s[0] >= 0.6;
    }

    private boolean meleeHeavy() {
        double[] s = recentHits();
        return s[0] >= POOL * 0.03 && s[1] / s[0] <= 0.15;
    }

    /** {total damage, projectile damage} over the last 8 seconds. */
    private double[] recentHits() {
        long cutoff = tick - 160;
        while (!hits.isEmpty() && hits.peekFirst()[0] < cutoff) {
            hits.pollFirst();
        }
        double total = 0;
        double proj = 0;
        for (double[] h : hits) {
            total += h[1];
            if (h[2] > 0.5) {
                proj += h[1];
            }
        }
        return new double[]{total, proj};
    }

    private double farFraction(List<Player> fighters) {
        if (fighters.isEmpty()) {
            return 0;
        }
        int far = 0;
        boolean veryFar = false;
        Location bl = boss.getLocation();
        for (Player p : fighters) {
            double d = bl.distance(p.getLocation());
            if (d > 16) {
                far++;
            }
            if (d > 18) {
                veryFar = true;
            }
        }
        return veryFar ? (double) far / fighters.size() : 0;
    }

    private boolean anyoneWithin(List<Player> fighters, double r) {
        Location bl = boss.getLocation();
        for (Player p : fighters) {
            if (Util.horiz(p.getLocation(), bl) <= r && Math.abs(p.getLocation().getY() - bl.getY()) <= 4) {
                return true;
            }
        }
        return false;
    }

    private void decayThreat() {
        if (tick % 20 == 0) {
            threat.replaceAll((k, v) -> v * 0.92);
        }
    }

    // =================================================================== helpers

    private boolean ready(String key) {
        return tick >= cd.getOrDefault(key, 0L);
    }

    private void setCd(String key, int ticks) {
        double scale = (enraged ? 0.6 : 1.0) * (phase == 3 ? 0.8 : 1.0);
        cd.put(key, tick + (long) (ticks * scale));
    }

    private void hurt(Player p, double base) {
        double d = base * plugin.getConfig().getDouble("boss.damage-multiplier", 1.0) * (enraged ? 1.4 : 1.0);
        if (plugin.items().fullSet(p)) {
            d *= 0.7;
        }
        p.damage(d, boss);
    }

    private void slow(Player p, int amp, int ticks) {
        p.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, ticks, amp, false, true, true));
    }

    private static void setBase(LivingEntity e, Attribute attr, double value) {
        AttributeInstance ai = e.getAttribute(attr);
        if (ai != null) {
            ai.setBaseValue(value);
        }
    }

    private void glowTeam(Entity e) {
        Scoreboard sb = Bukkit.getScoreboardManager().getMainScoreboard();
        Team t = sb.getTeam(TEAM);
        if (t == null) {
            t = sb.registerNewTeam(TEAM);
            t.color(NamedTextColor.AQUA);
        }
        t.addEntity(e);
    }

    private boolean eligible(Player p) {
        return p.isOnline() && !p.isDead()
                && (p.getGameMode() == GameMode.SURVIVAL || p.getGameMode() == GameMode.ADVENTURE);
    }

    private List<Player> fighters() {
        List<Player> out = new ArrayList<>();
        double r2 = radius * radius;
        for (Player p : world.getPlayers()) {
            if (eligible(p) && p.getLocation().distanceSquared(home) <= r2) {
                out.add(p);
            }
        }
        return out;
    }

    private void updateBar() {
        float prog = (float) Math.max(0, Math.min(1, boss.getHealth() / POOL));
        bar.progress(prog);
        bar.name(Util.mm("<aqua><bold>Winter Witch</bold> <dark_gray>|</dark_gray> <white>" + (int) Math.ceil(prog * effectiveMax)
                + "</white><gray>/" + (int) effectiveMax + " <dark_gray>|</dark_gray> <gray>Phase " + phase
                + (enraged ? " <red>ENRAGED" : "")));
        if (tick % 20 == 0) {
            double show = radius + 40;
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (p.getWorld() == world && p.getLocation().distanceSquared(home) <= show * show) {
                    p.showBossBar(bar);
                } else {
                    p.hideBossBar(bar);
                }
            }
        }
    }

    /** Finds standing room (3 blocks tall) near the given column, or null. */
    private Location findSafe(Location base) {
        World w = base.getWorld();
        if (w == null) {
            return null;
        }
        int x = base.getBlockX();
        int z = base.getBlockZ();
        for (int dy = 3; dy >= -5; dy--) {
            int y = base.getBlockY() + dy;
            Block feet = w.getBlockAt(x, y, z);
            Block head = w.getBlockAt(x, y + 1, z);
            Block head2 = w.getBlockAt(x, y + 2, z);
            Block below = w.getBlockAt(x, y - 1, z);
            if (feet.isPassable() && !feet.isLiquid() && head.isPassable() && head2.isPassable()
                    && below.getType().isSolid()) {
                return new Location(w, x + 0.5, y, z + 0.5);
            }
        }
        return null;
    }
}
