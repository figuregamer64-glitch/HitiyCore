package com.hitiysmp.winterwitch;

import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.EquipmentSlotGroup;
import org.bukkit.inventory.ItemRarity;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.components.EquippableComponent;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.persistence.PersistentDataType;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public final class Items {
    public static final String FROSTBRAND = "frostbrand";
    public static final String HELMET = "frostheart_helmet";
    public static final String CHESTPLATE = "frostheart_chestplate";
    public static final String LEGGINGS = "frostheart_leggings";
    public static final String BOOTS = "frostheart_boots";
    public static final String SIGIL = "sigil";

    private final WinterWitchPlugin plugin;
    private final NamespacedKey tagKey;
    private final File coinFile;
    private ItemStack coinTemplate;

    Items(WinterWitchPlugin plugin) {
        this.plugin = plugin;
        this.tagKey = new NamespacedKey(plugin, "item");
        this.coinFile = new File(plugin.getDataFolder(), "coin.yml");
        reload();
    }

    void reload() {
        coinTemplate = null;
        if (coinFile.exists()) {
            YamlConfiguration y = YamlConfiguration.loadConfiguration(coinFile);
            coinTemplate = y.getItemStack("coin");
        }
        if (coinTemplate == null) {
            coinTemplate = defaultCoin();
        }
    }

    private static NamespacedKey key(String path) {
        return Objects.requireNonNull(NamespacedKey.fromString("winterwitch:" + path));
    }

    // ---------------------------------------------------------------- coins

    private ItemStack defaultCoin() {
        ItemStack it = new ItemStack(Material.FEATHER);
        ItemMeta m = it.getItemMeta();
        m.displayName(Util.mm("<!italic><white>HitiyCoin"));
        m.setRarity(ItemRarity.RARE);
        m.setItemModel(NamespacedKey.minecraft("emerald"));
        m.setEnchantmentGlintOverride(true);
        it.setItemMeta(m);
        return it;
    }

    /** Saves the exact item as the reward coin so it always matches the real HitiyCoin. */
    public boolean setCoinTemplate(ItemStack item) {
        ItemStack t = item.clone();
        t.setAmount(1);
        YamlConfiguration y = new YamlConfiguration();
        y.set("coin", t);
        try {
            plugin.getDataFolder().mkdirs();
            y.save(coinFile);
        } catch (IOException ex) {
            return false;
        }
        coinTemplate = t;
        return true;
    }

    public void giveCoins(Player p, int amount) {
        int left = amount;
        while (left > 0) {
            ItemStack c = coinTemplate.clone();
            int n = Math.min(left, c.getMaxStackSize());
            c.setAmount(n);
            giveOrDrop(p, c);
            left -= n;
        }
    }

    public void giveOrDrop(Player p, ItemStack it) {
        for (ItemStack rest : p.getInventory().addItem(it).values()) {
            p.getWorld().dropItemNaturally(p.getLocation(), rest);
        }
    }

    // ------------------------------------------------------------ identification

    public String idOf(ItemStack s) {
        if (s == null || !s.hasItemMeta()) {
            return null;
        }
        return s.getItemMeta().getPersistentDataContainer().get(tagKey, PersistentDataType.STRING);
    }

    private void tag(ItemMeta m, String id) {
        m.getPersistentDataContainer().set(tagKey, PersistentDataType.STRING, id);
    }

    public boolean fullSet(Player p) {
        PlayerInventory inv = p.getInventory();
        return HELMET.equals(idOf(inv.getHelmet()))
                && CHESTPLATE.equals(idOf(inv.getChestplate()))
                && LEGGINGS.equals(idOf(inv.getLeggings()))
                && BOOTS.equals(idOf(inv.getBoots()));
    }

    // ------------------------------------------------------------ weapon

    public ItemStack frostbrand() {
        ItemStack it = new ItemStack(Material.NETHERITE_SWORD);
        ItemMeta m = it.getItemMeta();
        m.displayName(Util.mm("<!italic><aqua><bold>Witch's Frostbrand"));
        List<Component> lore = new ArrayList<>();
        lore.add(Util.mm("<!italic><gray>Forged from the frozen heart"));
        lore.add(Util.mm("<!italic><gray>of the Winter Witch."));
        lore.add(Component.empty());
        lore.add(Util.mm("<!italic><aqua>Chill <dark_gray>- <gray>25% chance to freeze a target"));
        lore.add(Util.mm("<!italic><aqua>Cold Snap <dark_gray>- <gray>Right-click: frost wave (30s)"));
        m.lore(lore);
        m.setRarity(ItemRarity.EPIC);
        m.setItemModel(key("frostbrand"));
        m.addEnchant(Enchantment.SHARPNESS, 5, true);
        m.addEnchant(Enchantment.UNBREAKING, 3, true);
        m.addEnchant(Enchantment.LOOTING, 3, true);
        m.addEnchant(Enchantment.SWEEPING_EDGE, 3, true);
        m.addEnchant(Enchantment.MENDING, 1, true);
        // Overrides the default sword stats: 9 damage total, normal sword speed.
        m.addAttributeModifier(Attribute.ATTACK_DAMAGE, new AttributeModifier(
                NamespacedKey.minecraft("base_attack_damage"), 8.0,
                AttributeModifier.Operation.ADD_NUMBER, EquipmentSlotGroup.MAINHAND));
        m.addAttributeModifier(Attribute.ATTACK_SPEED, new AttributeModifier(
                NamespacedKey.minecraft("base_attack_speed"), -2.4,
                AttributeModifier.Operation.ADD_NUMBER, EquipmentSlotGroup.MAINHAND));
        tag(m, FROSTBRAND);
        it.setItemMeta(m);
        return it;
    }

    // ------------------------------------------------------------ armor

    public ItemStack armorPiece(String id) {
        Material mat;
        String name;
        EquipmentSlot slot;
        EquipmentSlotGroup group;
        double armor;
        String model;
        switch (id) {
            case HELMET -> {
                mat = Material.NETHERITE_HELMET;
                name = "Frostheart Crown";
                slot = EquipmentSlot.HEAD;
                group = EquipmentSlotGroup.HEAD;
                armor = 3;
                model = "frostheart_helmet";
            }
            case CHESTPLATE -> {
                mat = Material.NETHERITE_CHESTPLATE;
                name = "Frostheart Mantle";
                slot = EquipmentSlot.CHEST;
                group = EquipmentSlotGroup.CHEST;
                armor = 8;
                model = "frostheart_chestplate";
            }
            case LEGGINGS -> {
                mat = Material.NETHERITE_LEGGINGS;
                name = "Frostheart Greaves";
                slot = EquipmentSlot.LEGS;
                group = EquipmentSlotGroup.LEGS;
                armor = 6;
                model = "frostheart_leggings";
            }
            default -> {
                mat = Material.NETHERITE_BOOTS;
                name = "Frostheart Treads";
                slot = EquipmentSlot.FEET;
                group = EquipmentSlotGroup.FEET;
                armor = 3;
                model = "frostheart_boots";
            }
        }
        ItemStack it = new ItemStack(mat);
        ItemMeta m = it.getItemMeta();
        m.displayName(Util.mm("<!italic><aqua><bold>" + name));
        List<Component> lore = new ArrayList<>();
        lore.add(Util.mm("<!italic><gray>Part of the <aqua>Frostheart <gray>set."));
        lore.add(Component.empty());
        lore.add(Util.mm("<!italic><aqua>Winter's Embrace <dark_gray>(4 pieces)"));
        lore.add(Util.mm("<!italic><gray> - Immune to freezing and the blizzard"));
        lore.add(Util.mm("<!italic><gray> - 30% less damage from the Winter Witch"));
        m.lore(lore);
        m.setRarity(ItemRarity.EPIC);
        m.setItemModel(key(model));
        EquippableComponent eq = m.getEquippable();
        eq.setSlot(slot);
        eq.setModel(key("frostheart"));
        m.setEquippable(eq);

        m.addEnchant(Enchantment.PROTECTION, 4, true);
        m.addEnchant(Enchantment.UNBREAKING, 3, true);
        m.addEnchant(Enchantment.MENDING, 1, true);
        switch (id) {
            case HELMET -> {
                m.addEnchant(Enchantment.RESPIRATION, 3, true);
                m.addEnchant(Enchantment.AQUA_AFFINITY, 1, true);
            }
            case LEGGINGS -> m.addEnchant(Enchantment.SWIFT_SNEAK, 3, true);
            case BOOTS -> {
                m.addEnchant(Enchantment.FEATHER_FALLING, 4, true);
                m.addEnchant(Enchantment.FROST_WALKER, 2, true);
            }
            default -> {
            }
        }

        m.addAttributeModifier(Attribute.ARMOR, new AttributeModifier(new NamespacedKey(plugin, id + "_armor"),
                armor, AttributeModifier.Operation.ADD_NUMBER, group));
        m.addAttributeModifier(Attribute.ARMOR_TOUGHNESS, new AttributeModifier(new NamespacedKey(plugin, id + "_tough"),
                3.0, AttributeModifier.Operation.ADD_NUMBER, group));
        m.addAttributeModifier(Attribute.KNOCKBACK_RESISTANCE, new AttributeModifier(new NamespacedKey(plugin, id + "_kb"),
                0.1, AttributeModifier.Operation.ADD_NUMBER, group));
        m.addAttributeModifier(Attribute.MAX_HEALTH, new AttributeModifier(new NamespacedKey(plugin, id + "_hp"),
                2.0, AttributeModifier.Operation.ADD_NUMBER, group));
        tag(m, id);
        it.setItemMeta(m);
        return it;
    }

    public List<String> armorIds() {
        return List.of(HELMET, CHESTPLATE, LEGGINGS, BOOTS);
    }

    // ------------------------------------------------------------ sigil

    public ItemStack sigil() {
        ItemStack it = new ItemStack(Material.ECHO_SHARD);
        ItemMeta m = it.getItemMeta();
        m.displayName(Util.mm("<!italic><aqua><bold>Winter Sigil"));
        List<Component> lore = new ArrayList<>();
        lore.add(Util.mm("<!italic><gray>A shard of endless winter."));
        lore.add(Util.mm("<!italic><gray>Right-click to call the <aqua>Winter Witch<gray>."));
        lore.add(Util.mm("<!italic><red>Bring friends. Bring warmth."));
        m.lore(lore);
        m.setRarity(ItemRarity.EPIC);
        m.setItemModel(key("sigil"));
        m.setEnchantmentGlintOverride(true);
        tag(m, SIGIL);
        it.setItemMeta(m);
        return it;
    }

    public ItemStack byName(String name) {
        return switch (name.toLowerCase()) {
            case "frostbrand", "sword" -> frostbrand();
            case "helmet" -> armorPiece(HELMET);
            case "chestplate" -> armorPiece(CHESTPLATE);
            case "leggings" -> armorPiece(LEGGINGS);
            case "boots" -> armorPiece(BOOTS);
            case "sigil" -> sigil();
            default -> null;
        };
    }
}
