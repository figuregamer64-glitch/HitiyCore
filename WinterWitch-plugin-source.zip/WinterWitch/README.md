# WinterWitch (Season 2 raid boss)

## Install
1. Use the prebuilt WinterWitch.jar, or build with JDK 25: `./build.sh <paper-api jar from libraries/io/papermc/paper/paper-api/...> [libraries folder]`. Drop the jar in `plugins/`.
2. Resource pack: host `WinterWitch-ResourcePack.zip` somewhere with a direct link and set it as your
   server resource pack (server.properties `resource-pack=` + `resource-pack-sha1=`).
   If it says the pack is for a different version, accept anyway or edit min_format/max_format in pack.mcmeta.
3. In game, hold a real HitiyCoin and run `/ww setcoin` so boss coin rewards match your economy exactly.

## Commands (permission winterwitch.admin)
- `/ww summon` start the fight where you stand (10s countdown)
- `/ww stop` end it, no rewards
- `/ww status`, `/ww phase <2|3>` (jump phases to test)
- `/ww give <player> <coin|frostbrand|helmet|chestplate|leggings|boots|set|sigil> [amount]`
- `/ww reload`

Players summon her with the **Winter Sigil** (right-click). Give sigils out, sell them, or let her drop them.

## Arena (mammoth-walley crater)
The schematic is built in to the jar. It is pasted ONCE into its own void world (`winter_arena`), so your
survival terrain is never touched. WorldEdit is not needed (the plugin has its own paster).
1. `/ww paste` - builds the arena (2.1M blocks, spread across ticks; a few minutes, watch the action bar / console).
2. `/ww arena tp` - look around. `/ww arena leave` to come back.
3. Players use the Winter Sigil: a frozen gate opens, everyone within 25 blocks is pulled into the crater
   (east side), the witch appears ~4s later, and everyone is sent home after the fight.
Blocks can't be broken/placed/exploded in the arena (creative is exempt). The 4 trial spawners in the map are swapped
for stone so they can't spawn mobs. All arena numbers are in config.yml under `arena:`.

## The fight
- Phase 1 (100-70%): Ice Lance (aimed where you'll be, dodge it), Hailstorm, Frost Nova if you hug her.
- Phase 2 (70-35%): blizzard (stay in the moving warm zones), Glacier Fall meteors, Frost Thralls.
- Phase 3 (<35%): Winter's Grasp, mirror images (the real witch has the constant snowflake aura), faster cooldowns.
- Enrage after 8 min: no warm zones, more damage.
- She adapts: arrow spam -> projectile barrier; camping -> meteors on you; hiding/pillaring -> she blinks to you;
  kiting -> she drags you in; hugging her -> faster Frost Nova.

## Loot
HitiyCoin (scaled by damage share), Witch's Frostbrand (top damage guaranteed, others chance),
Frostheart armor pieces, Winter Sigil. Tune everything in config.yml.
